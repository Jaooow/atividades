<?php
	setcookie('cpf');
	setcookie('permissao');
	setcookie('email');

	header("location: form_login.html");
?>